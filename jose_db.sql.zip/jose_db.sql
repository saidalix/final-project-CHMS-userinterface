-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 12, 2017 at 12:01 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `jose_db`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `chat_tbl`
-- 

CREATE TABLE `chat_tbl` (
  `ChID` int(11) NOT NULL auto_increment,
  `Emp_full_name` varchar(65) NOT NULL,
  `Eemail` varchar(50) NOT NULL,
  `message` varchar(250) NOT NULL,
  PRIMARY KEY  (`ChID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `chat_tbl`
-- 

INSERT INTO `chat_tbl` (`ChID`, `Emp_full_name`, `Eemail`, `message`) VALUES 
(1, 'Mwenge', 'mwenge@gmail.com', 'a customer named Patient Musafiri has paid 20000sh for a one posh of tororo cement; he will come tomorow to complete the balance');

-- --------------------------------------------------------

-- 
-- Table structure for table `contact_tbl`
-- 

CREATE TABLE `contact_tbl` (
  `CoID` int(11) NOT NULL auto_increment,
  `Full_Name` varchar(60) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `company` varchar(60) NOT NULL,
  `message` varchar(200) NOT NULL,
  PRIMARY KEY  (`CoID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `contact_tbl`
-- 

INSERT INTO `contact_tbl` (`CoID`, `Full_Name`, `email`, `phone`, `company`, `message`) VALUES 
(1, 'Clemence Patayo', 'clemencepatayo@gmail.com', '+256756841859', 'st.Lawrence Schools', 'the product you sent us last time were of good quality, we will work with you again');

-- --------------------------------------------------------

-- 
-- Table structure for table `customer_tbl`
-- 

CREATE TABLE `customer_tbl` (
  `CusID` int(11) NOT NULL auto_increment,
  `Cfname` varchar(50) NOT NULL,
  `Clname` varchar(50) NOT NULL,
  `Cusername` varchar(50) NOT NULL,
  `Cphone` varchar(50) NOT NULL,
  `Cemail` varchar(50) NOT NULL,
  `Cpass` varchar(20) NOT NULL,
  PRIMARY KEY  (`CusID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `customer_tbl`
-- 

INSERT INTO `customer_tbl` (`CusID`, `Cfname`, `Clname`, `Cusername`, `Cphone`, `Cemail`, `Cpass`) VALUES 
(1, 'Clemence', 'Patayo', 'clemencep', '+256756841859', 'clemence@gmail.com', 'like'),
(2, 'Said', 'Ahmed', 'Ahamedsaid', '+255698631421', 'ahamed@yahoo.com', 'love');

-- --------------------------------------------------------

-- 
-- Table structure for table `delivery_tbl`
-- 

CREATE TABLE `delivery_tbl` (
  `DID` int(11) NOT NULL auto_increment,
  `Cus_full_name` varchar(60) NOT NULL,
  `Cemail` varchar(50) NOT NULL,
  `Cphone` varchar(20) NOT NULL,
  `Address` varchar(65) NOT NULL,
  `Item_Quantity` varchar(65) NOT NULL,
  PRIMARY KEY  (`DID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `delivery_tbl`
-- 

INSERT INTO `delivery_tbl` (`DID`, `Cus_full_name`, `Cemail`, `Cphone`, `Address`, `Item_Quantity`) VALUES 
(1, 'Said Ahmed', 'said@gmail.com', '+25677658932', 'Mengo city', '12 sadolin paint of 5L');

-- --------------------------------------------------------

-- 
-- Table structure for table `employee_tbl`
-- 

CREATE TABLE `employee_tbl` (
  `EmpID` int(11) NOT NULL auto_increment,
  `Efname` varchar(50) NOT NULL,
  `Elname` varchar(50) NOT NULL,
  `Eusername` varchar(50) NOT NULL,
  `Ephone` varchar(50) NOT NULL,
  `Eemail` varchar(50) NOT NULL,
  `Epass` varchar(20) NOT NULL,
  PRIMARY KEY  (`EmpID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `employee_tbl`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `inventory_tbl`
-- 

CREATE TABLE `inventory_tbl` (
  `IID` int(11) NOT NULL auto_increment,
  `Item_name` varchar(50) NOT NULL,
  `uprice` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date_of_entry` varchar(25) NOT NULL,
  `other_details` varchar(60) NOT NULL,
  `quantity_sold` int(11) NOT NULL,
  `quantity_stored` int(11) NOT NULL,
  `totol_price` int(11) NOT NULL,
  PRIMARY KEY  (`IID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `inventory_tbl`
-- 

INSERT INTO `inventory_tbl` (`IID`, `Item_name`, `uprice`, `quantity`, `date_of_entry`, `other_details`, `quantity_sold`, `quantity_stored`, `totol_price`) VALUES 
(1, 'Cement', 35000, 10, '5 july 2017', 'Type: tororo', 0, 10, 350000),
(2, 'Cement', 35000, 5, '8 july 2017', 'tororo cement', 0, 5, 175000),
(3, 'Paint', 15000, 20, '8 july 2017', '10 sadolin paint\r\n5 regal paint\r\n5 silver paint', 0, 20, 300000);

-- --------------------------------------------------------

-- 
-- Table structure for table `ordering`
-- 

CREATE TABLE `ordering` (
  `ID` int(11) NOT NULL auto_increment,
  `Cus_full_name` varchar(60) NOT NULL,
  `Cemail` varchar(50) NOT NULL,
  `Item_name` varchar(60) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Size` varchar(20) NOT NULL,
  `Color` varchar(50) NOT NULL,
  `Type` varchar(50) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `ordering`
-- 

INSERT INTO `ordering` (`ID`, `Cus_full_name`, `Cemail`, `Item_name`, `Quantity`, `Size`, `Color`, `Type`) VALUES 
(1, 'clemence', 'clemencepatayo@gmail.com', 'Paint', 1, '20L', 'red', 'sadolin');

-- --------------------------------------------------------

-- 
-- Table structure for table `ordering_supl`
-- 

CREATE TABLE `ordering_supl` (
  `OSID` int(11) NOT NULL auto_increment,
  `supplier_name` varchar(60) NOT NULL,
  `email` varchar(50) NOT NULL,
  `Item_name` varchar(60) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date_of_ordering` varchar(25) NOT NULL,
  `message` varchar(250) NOT NULL,
  PRIMARY KEY  (`OSID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `ordering_supl`
-- 

INSERT INTO `ordering_supl` (`OSID`, `supplier_name`, `email`, `Item_name`, `quantity`, `date_of_ordering`, `message`) VALUES 
(1, 'Clemence', 'clemence@gmail.com', 'Cement', 20, '5 july 2017', 'type tororo\r\ndate of delivery before 20th'),
(2, 'Cement', '35000', '', 10, '5 july 2017', 'type: tororo cement\r\narrival date : 10 july 2017'),
(3, 'Said', 'said@gmail.com', 'door hardware', 1, '7 july 2017', 'color red'),
(4, 'Maguy Kisaka', 'kisaka@gmail.com', 'ceramic', 100, '', 'length 24 cm\r\ncolor white\r\n');

-- --------------------------------------------------------

-- 
-- Table structure for table `payement_supl`
-- 

CREATE TABLE `payement_supl` (
  `PSID` int(11) NOT NULL auto_increment,
  `supplier_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `Item_name` varchar(60) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `date_of_payement` varchar(25) NOT NULL,
  `message` varchar(50) NOT NULL,
  PRIMARY KEY  (`PSID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `payement_supl`
-- 

INSERT INTO `payement_supl` (`PSID`, `supplier_name`, `email`, `Item_name`, `quantity`, `amount`, `date_of_payement`, `message`) VALUES 
(1, 'Idia', 'idia@gmail.com', 'Cement', 10, 350000, '7 july 2017', 'tororo');

-- --------------------------------------------------------

-- 
-- Table structure for table `payement_tbl`
-- 

CREATE TABLE `payement_tbl` (
  `PID` int(11) NOT NULL auto_increment,
  `Cus_full_name` varchar(60) NOT NULL,
  `Cemail` varchar(50) NOT NULL,
  `Cphone` varchar(20) NOT NULL,
  `Address` varchar(60) NOT NULL,
  `Occupation` varchar(60) NOT NULL,
  `Mpayement` varchar(50) NOT NULL,
  `Item_name` varchar(60) NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY  (`PID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `payement_tbl`
-- 

INSERT INTO `payement_tbl` (`PID`, `Cus_full_name`, `Cemail`, `Cphone`, `Address`, `Occupation`, `Mpayement`, `Item_name`, `amount`) VALUES 
(1, 'Idia adams', 'idia@gmail.com', '+256756841859', 'St.Lawrence university', 'nurse', 'cash', 'decortive metal', 6);
